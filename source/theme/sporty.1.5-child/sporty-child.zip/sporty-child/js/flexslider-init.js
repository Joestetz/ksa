(function($) {
    $(window).load(function() {
        $('.flexslider').flexslider({
	            animation: 'fade'
	    });
    });
})(jQuery)